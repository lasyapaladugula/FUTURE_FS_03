-# Sunny Cafe — Local Business Website (FUTURE_FS_03)

Repository: https://github.com/<your-username>/FUTURE_FS_03

This is a small responsive website built for the Full Stack Web Development internship Task 3.

Files included:
- index.html — main site
- css/styles.css — styles
- js/script.js — small scripted UX
- README.md — run and deploy instructions
- pitch.md — short pitch to present to the business owner
- assets/ (logo, hero image, menu images, map placeholder, favicon)

How to run locally:
1. Open the folder in VS Code
2. Use Live Server extension or run a simple HTTP server:

```bash
# Python 3
python -m http.server 8000

# then open http://localhost:8000
```

Deploy to GitHub Pages:
1. Create a new public repo named `FUTURE_FS_03` on GitHub (or use the repo above).
2. Commit and push all files (recommended branch `main`).
3. In repo Settings → Pages, select branch `main` and `/ (root)` folder.
4. Wait a few minutes and your site will be live at `https://<your-username>.github.io/FUTURE_FS_03/`.

Form handling:
- The contact form will submit to Formspree if you set the `action` in `index.html` to your Formspree form URL. If no Formspree ID is set, the site simulates a submission locally and shows a success message for testing.

What to submit for the internship:
- Public GitHub repo named `FUTURE_FS_03` containing this project.
- Short demo link (GitHub Pages) and a pitch summary (see `pitch.md`).
