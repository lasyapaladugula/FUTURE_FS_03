# Pitch: Sunny Cafe Website — Quick Overview

Purpose
- Provide a clean, mobile-friendly web presence to attract local customers and collect leads/reservations.

Key benefits for the owner
- Professional look to build trust and showcase menu highlights.
- Contact form for reservations and customer messages (Formspree integration).
- Easy to update and host on GitHub Pages or any static hosting provider.

Suggested talking points for your live pitch (30–60 seconds)
1. Problem: "Many customers search for nearby cafes and expect basic info online — hours, menu, and contact."
2. Solution: "A responsive website that loads fast, shows top items, and lets customers book or message you directly."
3. Impact: "Increases walk-ins, streamlines reservation requests, and looks professional on mobile and desktop."

Next steps you can offer the owner
- Add daily/weekly specials and a simple mailing list signup.
- Integrate online ordering or reservations (optional) using a backend or third-party service.
